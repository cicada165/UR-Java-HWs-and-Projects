/* Name: Yue Liu
 * NetID: yliu165
 * Lab Session: TR 4:50pm - 6:05pm
 * I did not collaborate with anyone on this assignment.
*/

*This is the source code for Project 2. It contains one java files HuffmanSubmit. It contains all the methods as required as well as a main
class that execute all the methods. Priority queue is used to construct the huffman tree. 

*After running the code:
freq.txt is the Frenquency file;
alice30.enc and urenc.txt are the encode output; 
alice30dec.txt and urdec.jpg are the decode output.

*The source code is commented

*No additional file is included

