
/* Name: Yue Liu
 * NetID: yliu165
 * Lab Session: TR 4:50pm - 6:05pm
 *I did not collaborate with anyone on this assignment
*/

*P2 and P4 run in command line by specifying input file.
*P1 and P2 pseudocode is answered in doc file.


