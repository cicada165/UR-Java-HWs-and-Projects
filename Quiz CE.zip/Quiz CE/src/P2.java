import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.io.*;

public class P2 {

    @SuppressWarnings("unchecked")
    static int BFS(ArrayList<Integer>[] adj, int src, int dest, int n) {

        // dist[] is shortest distance from source
        int[] dist = new int[n];
        // paths[] is num of shortest paths from source
        int[] paths = new int[n];

        for (int i = 0; i < n; i++) {
            dist[i] = Integer.MAX_VALUE;
            paths[i] = 0;
        }

        // store whether ith vertex is reached at least once
        boolean[] visited = new boolean[n]; //initialize to false

        dist[src] = 0;
        paths[src] = 1;

        Queue<Integer> q = new LinkedList<>();
        q.add(src);
        visited[src] = true;

        while (!q.isEmpty()) {
            int curr = q.poll();

            // for all neighbors of the current vertex
            for (Integer x : adj[curr]) {

                if (visited[x] == false) {
                    q.add(x);
                    visited[x] = true;
                }

                // check if there is a better path
                if (dist[x] > dist[curr] + 1) {
                    dist[x] = dist[curr] + 1;
                    paths[x] = paths[curr];
                }
                // find additional shortest path
                else if (dist[x] == dist[curr] + 1) {
                    paths[x] += paths[curr];
                }
            }
        }
        // return the num of shortest paths from src to dest
        return paths[dest];
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {

        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(args[0]));

            String line = reader.readLine(); // read first line;
            int v = Integer.parseInt(line.split(" ")[0]); // Number of Vertices
            int e = Integer.parseInt(line.split(" ")[1]); // Number of Edges

            /** adjacency list for graph */
            // num of vertices + 1 since array starts at 0
            ArrayList<Integer>[] adj = new ArrayList[v+1];

            for (int i = 0; i < v+1; i++) {
                adj[i] = new ArrayList<>();
            }

            line = reader.readLine(); // read second line
            int src = Integer.parseInt(line.split(" ")[0]); // source
            int dest = Integer.parseInt(line.split(" ")[1]); // destination

            line = reader.readLine();
            while (line != null) {
                int x = Integer.parseInt(line.split(" ")[0]);
                int y = Integer.parseInt(line.split(" ")[1]);
                addEdge(adj, x, y);
                line = reader.readLine();
            }

            Integer numberOf = BFS(adj, src, dest, v+1); // number of shortest path
            System.out.println(numberOf);

            // write the output
            File out = new File("p2_out");
            FileOutputStream fos = new FileOutputStream(out);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write(numberOf.toString());
            bw.close();

        } catch (IOException e) {

        }
    }

    /** A static method that add edges to adjacency list */
    static void addEdge(ArrayList<Integer>[] adj, int x, int y) {
        adj[x].add(y);
        adj[y].add(x);
    }
}
