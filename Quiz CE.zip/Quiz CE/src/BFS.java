
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class BFS {
	public static Graph constructGraph()
	{		
		int noOfVertices,noOfEdges;
		Graph graph=null;

		int u, v;
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the number of Vertices: ");
		while(scanner.hasNext())
		{	
			
			noOfVertices=scanner.nextInt();
			System.out.print("Enter the number of Edges: ");
			noOfEdges=scanner.nextInt();


			graph=new Graph(noOfVertices);
			for(int i=0;i<noOfEdges;i++)
			{	
				System.out.println("Please enter an edge (two numbers): ");
				u=scanner.nextInt();
				v=scanner.nextInt();
				graph.addEdge(u, v);
				graph.addEdge(v, u);
			}
			break;
		}
		return graph;
	}

	public static ArrayList<Integer> doBFSShortestPath(Graph graph, int source, int dest)
	{
		ArrayList<Integer> shortestPathList = new ArrayList<Integer>();
		HashMap<Integer, Boolean> visited = new HashMap<Integer, Boolean>();

		if (source == dest)
			return null;
		Queue<Integer> queue = new LinkedList<Integer>();
		Stack<Integer> pathStack = new Stack<Integer>();

		queue.add(source);
		pathStack.add(source);
		visited.put(source, true);

		while(!queue.isEmpty())
		{
			int u = queue.poll();
			ArrayList<Integer> adjList = graph.getOutEdges(u);

			for(int v : adjList)
			{
				if(!visited.containsKey(v))
				{
					queue.add(v);
					visited.put(v, true);
					pathStack.add(v);
					if(u == dest)
						break;
				}
			}
		}

		int node, currentSrc=dest;
		shortestPathList.add(dest);
		while(!pathStack.isEmpty())
		{
			node = pathStack.pop();
			if(graph.isNeighbor(currentSrc, node))
			{
				shortestPathList.add(node);
				currentSrc = node;
				if(node == source)
					break;
			}
		}
		return shortestPathList;
		
	}

	public static void findShortestPath()
	{

		Graph graph = constructGraph();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Please enter the source: ");
		int source = scanner.nextInt();
		System.out.print("Please enter the destination: ");
		int dest = scanner.nextInt();

		ArrayList<Integer> shortestPathList =  doBFSShortestPath(graph, source, dest);

		System.out.print("[ ");
		for(int node : shortestPathList)
		{
			System.out.print(node+" ");
		}
		System.out.print("]");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BFS.findShortestPath();
	}

}