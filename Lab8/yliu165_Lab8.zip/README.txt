
/* Name: Yue Liu
 * NetID: yliu165
 * Lab Session: TR 4:50pm - 6:05pm
 *I did not collaborate with anyone on this assignment
*/

*This is the source code for Lab8. It contains one java files HashPlot.java. It contains all the methods as required
as well as a main class that execute all the methods. Running the program produces an output_sequence file and output.PNG through every run.

*The input sequence is downloaded from the blackboard. They are used for all 6 tables and does not change. 
Therefore, I will only include one input file and 6 output sequence, one for each png.

*The PNG are inlucded in the zip file comment with name corresponds to legend. 
Txt does not display png file, but comments are shown in below.
*Legend: a-b-m-quality

*Comment section:

1-1-120-better
This one looks fairly good with points distributed evenly

2-25-90-better
This one looks fairly good with points distributed evenly

5-8-100-better
This is not the best distribution available but the points are still adequately spread out compared to worse cases


20-80-90-not so good
Not very good. Data are not spread out enough.

40-10-120-not so good
This is a really bad distribution

80-10-120-not so good
Again, a very bad distribution.

